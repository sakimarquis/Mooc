try(dev.off(),silent=TRUE)
plot.new()