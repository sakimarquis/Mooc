# decisionmaking-code
*Mykel Kochenderfer, Tim Wheeler, and Kyle Wray*

All typeset code blocks from the book, [Algorithms for Decision Making](https://algorithmsbook.com/).

We share this content in the hopes that it helps you and makes the decision making algorithms
more approachable and accessible. Thank you for reading!

If you encounter any issues or have pressing comments, please [file an issue](https://github.com/algorithmsbooks/decisionmaking/issues/new/choose).
